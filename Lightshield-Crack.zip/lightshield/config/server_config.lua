Imo-Leak_Server = {}


--
-- AC NAME CONFIG AND THAT SHIT
--

Imo-Leak_Server.Servername = '🛡Light-Shield🛡' -- Your Server Name
Imo-Leak_Server.Banmessage = 'Exposed by Light-shield'
Imo-Leak_Server.KickMessage = 'You have been kicked by Light-Shield Anticheat'

Imo-Leak_Server.AntiCipher = true -- Dont change :c

--
-- Entitys
--
Imo-Leak_Server.Entity = true -- Deletes the object after limit
Imo-Leak_Server.EntityKick = true -- Kick player after limit ex. if i spawn 6 cars i will get kicked
Imo-Leak_Server.EntityBan = false -- Ban player after limit ex. if i spawn 6 cars i will get banned
-- The Limit will be reseted every 20 seconds --


Imo-Leak_Server.EntityVehicle = true
Imo-Leak_Server.EntityVehicleLimit = 3

Imo-Leak_Server.EntityPed = true
Imo-Leak_Server.EntityPedLimit = 5

Imo-Leak_Server.EntityObject = true


--
-- Anti Weapon
--
Imo-Leak_Server.AntiGiveWeapon = true -- Anti Give Weapon to other Players
Imo-Leak_Server.AntiRemoveWeapon = true -- Anti Remove Weapon to other Players

--
-- Anti remove from car
--
Imo-Leak_Server.AntiRemoveFromCar = true -- Anti Remove Other Players of Vehicle

--
-- Anti Particles
--
Imo-Leak_Server.AntiParticles = true
Imo-Leak_Server.AntiParticlesKick = true
Imo-Leak_Server.AntiParticlesBan = true
Imo-Leak_Server.AntiParticlesLimit = 5

--
-- Anti Jailall
--
Imo-Leak_Server.AntiJaillAll = true -- Your jail Event needs to be esx-qalle-jail:jailPlayer
Imo-Leak_Server.AntiJaillAllKick = true
Imo-Leak_Server.AntiJaillAllBan = true


--
-- BlacklistedEvents
--
Imo-Leak_Server.BlacklistedEvents = true
Imo-Leak_Server.BlacklistedEventsKick = true
Imo-Leak_Server.BlacklistedEventsBan = true
Imo-Leak_Server.BlacklistedEventsList = {
    'bringplayertome',
    'lester:vendita',
    'esx_ambulancejob:revive'
}

Imo-Leak_Server.MaxValuedEvents = { -- This can catch money spamming, on a vulnarable event, and can easily catch other event executions like these. Maxvalue means, if a player triggers a mavalued event, with an argument which is higer then maxvalue, the anticheat will block it.
	["esx_garbagejob:pay"] = {maxvalue=1000},
	["esx_pizza:pay"] = {maxvalue=1000},
	["esx_ranger:pay"] = {maxvalue=1000},
	["esx_truckerjob:pay"] = {maxvalue=1000},
	["esx_slotmachine:sv:2"] = {maxvalue=1000},
	["AdminMenu:giveBank"] = {maxvalue=1000},
	["AdminMenu:giveCash"] = {maxvalue=1000},
	["LegacyFuel:PayFuel"] = {maxvalue=1000},
	["fuel:pay"] = {maxvalue=1000},
	["esx_society:billing"] = {maxvalue=100000}                               -- Do {maxvalue=-1} if you only will get banned on -1 trigger. Good for Police triggers ;D
}

Imo-Leak_Server.AntiSpamTrigger = true

Imo-Leak_Server.AntiSpamTriggerList = { -- This can catch money spamming, on a vulnarable event, and can easily catch other event executions like these. Maxvalue means, if a player triggers a mavalued event, with an argument which is higer then maxvalue, the anticheat will block it.
    { EVENT = "esx_policejob:handcuff",           MAX_TIME = 4  },
    { EVENT = "esx-qalle-hunting:reward",         MAX_TIME = 3  },
    { EVENT = "esx:giveInventoryItem",            MAX_TIME = 4  },
    { EVENT = "esx_billing:sendBill" ,            MAX_TIME = 3  },
    { EVENT = "esx_billing:sendBill" ,            MAX_TIME = 3  },
    { EVENT = "chatE3vent" ,                      MAX_TIME = 2  },
    { EVENT = "_chat:messageEntered3" ,           MAX_TIME = 2  },
    { EVENT = "playerDi3ed" ,                     MAX_TIME = 2  },
    { EVENT = "gcPhone:_internalAddMessage",      MAX_TIME = 4  },
    { EVENT = "gcPhone:tchat_channel",            MAX_TIME = 4  },
    { EVENT = "ServerValidEmote",                 MAX_TIME = 4  },
    { EVENT = "lester:vendita",                   MAX_TIME = 20 },
    { EVENT = "esx:confiscatePlayerItem",         MAX_TIME = 4  },
    { EVENT = "esx_vehicleshop:setVehicleOwned",  MAX_TIME = 4  },
    { EVENT = "LegacyFuel:PayFuel",               MAX_TIME = 4  },
    { EVENT = "CarryPeople:sync",                 MAX_TIME = 3  },
    { EVENT = "fuel:pay",      MAX_TIME = 3  }
}

--
-- Anti CommunityServiceAll
--
Imo-Leak_Server.AntiCommunityServiceAll = true -- Your CommunityService Event needs to be 'esx_communityservice:sendToCommunityService
Imo-Leak_Server.AntiCommunityServiceAllKick = true
Imo-Leak_Server.AntiCommunityServiceAllBan = true


-- AntiAntiCheese (Hydro Menu)
Imo-Leak_Server.AntiAntiCheese = true

-- AntiDpemoteAll
Imo-Leak_Server.AntiDpemoteAll = true
Imo-Leak_Server.AntiDpemoteAllKick = false
Imo-Leak_Server.AntiDpemoteAllBan = true


-- AntiPolicejobExploits
Imo-Leak_Server.AntiPolicejobExploits = true
Imo-Leak_Server.AntiPolicejobExploitsKick = false
Imo-Leak_Server.AntiPolicejobExploitsBan = true


-- AntiTackleExploit
Imo-Leak_Server.AntiTackleExploit = true
Imo-Leak_Server.AntiTackleExploitKick = false
Imo-Leak_Server.AntiTackleExploitBan = true


-- Anti Carry all
Imo-Leak_Server.AntiCarryExploit = true
Imo-Leak_Server.AntiCarryExploitKick = false
Imo-Leak_Server.AntiCarryExploitBan = true


-- DiscordBotExploit
Imo-Leak_Server.DiscordBotExploit = true
Imo-Leak_Server.DiscordBotExploitKick = false
Imo-Leak_Server.DiscordBotExploitBan = true


-- PickupExploit
Imo-Leak_Server.PickupExploit = true
Imo-Leak_Server.PickupExploitKick = false
Imo-Leak_Server.PickupExploitBan = true


-- Kashacters Exploit ( )
Imo-Leak_Server.Kashacter = true
Imo-Leak_Server.KashacterKick = false
Imo-Leak_Server.KashacterBan = true



--
-- Explosions
--
Imo-Leak_Server.AntiExplosion = true -- Disables Explosion
Imo-Leak_Server.AntiExplosionKick = true -- want to get banned?
Imo-Leak_Server.AntiExplosionBan = true -- want to get banned?
Imo-Leak_Server.BlacklistedExplosions = {  -- Blacklisted Explosions
    1,
    2, 
    4, 
    5,
    25,
    31,
    29, 
    32, 
    33, 
    35, 
    36, 
    37, 
    38,
    39
}


