

Lightshield = {}

Lightshield.MainWebhook = 'https://discord.com/api/webhooks/980907556237090867/kmLJMXUB-ipQ0un63-PAsjxxTLSRElv53k1phnr8ONK7qgI9b5ce4KT0w1h31BXpec8N'
Lightshield.BanWebhook = 'https://discord.com/api/webhooks/980907556237090867/kmLJMXUB-ipQ0un63-PAsjxxTLSRElv53k1phnr8ONK7qgI9b5ce4KT0w1h31BXpec8N'
Lightshield.ScreenshotWebhook = 'https://discord.com/api/webhooks/980907556237090867/kmLJMXUB-ipQ0un63-PAsjxxTLSRElv53k1phnr8ONK7qgI9b5ce4KT0w1h31BXpec8N'
Lightshield.ExplosionWebhook = 'https://discord.com/api/webhooks/980907556237090867/kmLJMXUB-ipQ0un63-PAsjxxTLSRElv53k1phnr8ONK7qgI9b5ce4KT0w1h31BXpec8N'
Lightshield.PublicBanWebhook = 'https://discord.com/api/webhooks/980907556237090867/kmLJMXUB-ipQ0un63-PAsjxxTLSRElv53k1phnr8ONK7qgI9b5ce4KT0w1h31BXpec8N'
Lightshield.ConnectWebhook = 'https://discord.com/api/webhooks/980907556237090867/kmLJMXUB-ipQ0un63-PAsjxxTLSRElv53k1phnr8ONK7qgI9b5ce4KT0w1h31BXpec8N' -- Leave And Join!